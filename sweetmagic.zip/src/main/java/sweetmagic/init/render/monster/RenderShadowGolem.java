package sweetmagic.init.render.monster;

import net.minecraft.client.renderer.entity.RenderIronGolem;
import net.minecraft.client.renderer.entity.RenderManager;

public class RenderShadowGolem extends RenderIronGolem {

//	private static final ResourceLocation TEX = new ResourceLocation("textures/entity/wolf/wolf_tame.png");

	public RenderShadowGolem(RenderManager renderManager) {
		super(renderManager);
	}

//	@Override
//	protected ResourceLocation getEntityTexture(EntityWolf entity) {
//		return TEX;
//	}

//	@Override
//	protected void preRenderCallback(EntityIronGolem entity, float partialTickTime) {
//		super.preRenderCallback(entity, partialTickTime);
//		GlStateManager.enableBlend();
//		GlStateManager.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
//	}

//	@Overrs
}
