package sweetmagic.init.item.sm.eitem;

public enum SMType {

	SHOTTER,	// 射撃
	AIR,		// 空中
	GROUND,		// 地面
	MOB,		// モブ
	CHARGE;		// 溜め

	SMType () { }
}
