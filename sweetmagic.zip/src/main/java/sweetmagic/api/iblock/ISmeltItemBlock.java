package sweetmagic.api.iblock;

public interface ISmeltItemBlock {

	// 精錬時間の取得
	int getSmeltTime();
}
