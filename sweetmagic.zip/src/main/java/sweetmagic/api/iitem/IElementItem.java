package sweetmagic.api.iitem;

import sweetmagic.init.item.sm.eitem.SMElement;

public interface IElementItem {

	// 属性取得
	SMElement getElement();

	// 属性設定
	void setElement(SMElement ele);
}
